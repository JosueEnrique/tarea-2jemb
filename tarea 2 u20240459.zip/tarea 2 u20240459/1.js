//Crea un objeto Date para la fecha : Feb 20, 2012, 3:12 am. Deberá formatear la hora para que muestre la que aquí se le indica 
var fecha = new Date(2012, 1, 20, 3, 12, 0);